package com.todolist.service;

import com.todolist.dto.TodoRequest;
import com.todolist.entity.Todo;
import com.todolist.repository.TodoRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class TodoService {

    private final TodoRepository todoRepository;

    public List<Todo> getAllTodos() {
        return todoRepository.findAll();
    }

    public Todo createTodo(TodoRequest request) {
        Todo todo = Todo.builder()
                .todoNm(request.getTodoNm())
                .achievement(request.isAchievement())
                .dueDate(request.getDueDate())
                .priority(request.getPriority())
                .description(request.getDescription())
                .registeredAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
        return todoRepository.save(todo);
    }
}
